package pe.edu.upc.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.entity.Articulo;
import pe.edu.upc.service.IArticuloService;

@Named
@RequestScoped
public class ArticuloController implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private IArticuloService mService;
	private Articulo articulo;
	List<Articulo> listaArticulos;
	
	@PostConstruct
	public void init() {
		this.listaArticulos = new ArrayList<Articulo>();
		this.articulo = new Articulo();
		this.listar();
	}
	
	public String nuevoArticulo() {
		this.setArticulo(new Articulo());
		return "articulo.xhtml";
	}
	
	public void insertar() {
		try {
			mService.insertar(articulo);
			limpiarArticulo();
			//this.listar();
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
		
	public void listar() {
		try {
			listaArticulos = mService.listar();
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}		
	}
	
	public void limpiarArticulo() {
		this.init();
	}
	
	public void eliminar(Articulo ar) {
		try {
			mService.eliminar(ar.getIdArticulo());
			this.listar();
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}			
	}

	public Articulo getArticulo() {
		return articulo;
	}

	public void setArticulo(Articulo articulo) {
		this.articulo = articulo;
	}

	public List<Articulo> getListaArticulos() {
		return listaArticulos;
	}

	public void setListaArticulos(List<Articulo> listaArticulos) {
		this.listaArticulos = listaArticulos;
	}



}
