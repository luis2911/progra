package pe.edu.upc.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.entity.Categoria;
import pe.edu.upc.service.ICategoriaService;

@Named
@RequestScoped
public class CategoriaController implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private ICategoriaService mService;
	private Categoria categoria;
	List<Categoria> listaCategoria;
	
	@PostConstruct
	public void init() {
		this.listaCategoria = new ArrayList<Categoria>();
		this.categoria = new Categoria();
		this.listar();
	}
	
	public String nuevoCategoria() {
		this.setCategoria(new Categoria());
		return "categoria.xhtml";
	}
	
	public void insertar() {
		try {
			mService.insertar(categoria);
			limpiarCategoria();
			//this.listar();
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
		
	public void listar() {
		try {
			listaCategoria = mService.listar();
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}		
	}
	
	public void limpiarCategoria() {
		this.init();
	}
	
	public void eliminar(Categoria ca) {
		try {
			mService.eliminar(ca.getIdCategoria());
			this.listar();
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}			
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public List<Categoria> getListaCategoria() {
		return listaCategoria;
	}

	public void setListaCategoria(List<Categoria> listaCategoria) {
		this.listaCategoria = listaCategoria;
	}
}