package pe.edu.upc.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.entity.Juegos;
import pe.edu.upc.service.IJuegosService;

@Named
@RequestScoped
public class JuegosController implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private IJuegosService mService;
	private Juegos juegos;
	List<Juegos> listaJuegos;
	
	@PostConstruct
	public void init() {
		this.listaJuegos = new ArrayList<Juegos>();
		this.juegos = new Juegos();
		this.listar();
	}
	
	public String nuevoJuegos() {
		this.setJuegos(new Juegos());
		return "juegos.xhtml";
	}
	
	public void insertar() {
		try {
			mService.insertar(juegos);
			limpiarJuegos();
			//this.listar();
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
		
	public void listar() {
		try {
			listaJuegos = mService.listar();
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}		
	}
	
	public void limpiarJuegos() {
		this.init();
	}
	
	public void eliminar(Juegos ju) {
		try {
			mService.eliminar(ju.getIdJuegos());
			this.listar();
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}			
	}

	public Juegos getJuegos() {
		return juegos;
	}

	public void setJuegos(Juegos juegos) {
		this.juegos = juegos;
	}

	public List<Juegos> getListaJuegos() {
		return listaJuegos;
	}

	public void setListaJuegos(List<Juegos> listaJuegos) {
		this.listaJuegos = listaJuegos;
	}
	
	
	

}
