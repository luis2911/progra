package pe.edu.upc.dao;

import java.util.List;
import pe.edu.upc.entity.Articulo;

public interface IArticuloDao {
	public void insertar(Articulo articulo);
	public List<Articulo> listar();
	public void eliminar(int idArticulo);
}
