package pe.edu.upc.daoimpl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import pe.edu.upc.dao.IArticuloDao;
import pe.edu.upc.entity.Articulo;

public class ArticuloDaoImpl implements IArticuloDao, Serializable {

	private static final long serialVersionUID = 1L;
	
	@PersistenceContext(unitName = "a")
	private EntityManager em;

	@Transactional
	@Override
	public void insertar(Articulo articulo) {
		try {
			em.persist(articulo);
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public List<Articulo> listar() {
		List<Articulo> lista = new ArrayList<Articulo>();
		try {
			Query q = em.createQuery("select a from Articulo a");
			lista = (List<Articulo>) q.getResultList();
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		return lista;
	}

	@Transactional
	@Override
	public void eliminar(int idArticulo) {
		Articulo art = new Articulo();
		try {
			art = em.getReference(Articulo.class,idArticulo);
			em.remove(art);
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}				
	}

}
