package pe.edu.upc.daoimpl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import pe.edu.upc.dao.IJuegosDao;
import pe.edu.upc.entity.Juegos;

public class JuegosDaoImpl implements IJuegosDao, Serializable {

	private static final long serialVersionUID = 1L;
	
	@PersistenceContext(unitName = "a")
	private EntityManager em;

	@Transactional
	@Override
	public void insertar(Juegos juegos) {
		try {
			em.persist(juegos);
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public List<Juegos> listar() {
		List<Juegos> lista = new ArrayList<Juegos>();
		try {
			Query q = em.createQuery("select j from Juegos j");
			lista = (List<Juegos>) q.getResultList();
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		return lista;
	}

	@Transactional
	@Override
	public void eliminar(int idJuegos) {
		Juegos jue = new Juegos();
		try {
			jue = em.getReference(Juegos.class,idJuegos);
			em.remove(jue);
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}				
	}

}
