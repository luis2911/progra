package pe.edu.upc.service;

import java.util.List;

import pe.edu.upc.entity.Articulo;

public interface IArticuloService {
	public void insertar(Articulo articulo);
	public List<Articulo> listar();
	public void eliminar(int idArticulo);
}
