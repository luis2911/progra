package pe.edu.upc.service;

import java.util.List;

import pe.edu.upc.entity.Juegos;

public interface IJuegosService {
	public void insertar(Juegos juegos);
	public List<Juegos> listar();
	public void eliminar(int idJuegos);
}
