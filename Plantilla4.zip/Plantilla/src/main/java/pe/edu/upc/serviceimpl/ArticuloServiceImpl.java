package pe.edu.upc.serviceimpl;

import java.io.Serializable;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.dao.IArticuloDao;
import pe.edu.upc.entity.Articulo;
import pe.edu.upc.service.IArticuloService;

@Named
@RequestScoped

public class ArticuloServiceImpl implements IArticuloService, Serializable {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private IArticuloDao mD;

	@Override
	public void insertar(Articulo articulo) {
		mD.insertar(articulo);		
	}

	@Override
	public List<Articulo> listar() {
		return mD.listar();
	}

	@Override
	public void eliminar(int idArticulo) {
		mD.eliminar(idArticulo);		
	}

}
