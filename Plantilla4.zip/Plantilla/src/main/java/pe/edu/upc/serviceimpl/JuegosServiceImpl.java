package pe.edu.upc.serviceimpl;

import java.io.Serializable;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.dao.IJuegosDao;
import pe.edu.upc.entity.Juegos;
import pe.edu.upc.service.IJuegosService;

@Named
@RequestScoped

public class JuegosServiceImpl implements IJuegosService, Serializable {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private IJuegosDao mD;

	@Override
	public void insertar(Juegos juegos) {
		mD.insertar(juegos);		
	}

	@Override
	public List<Juegos> listar() {
		return mD.listar();
	}

	@Override
	public void eliminar(int idJuegos) {
		mD.eliminar(idJuegos);		
	}

}
