package pe.edu.upc.spring.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Positive;
import javax.validation.constraints.PositiveOrZero;


@Entity
@Table(name="juegos")
public class Juegos implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idJuegos;
	
    @NotBlank(message="Ingrese el nombre del juego")
	@Column(name="nombre_juegos", nullable=false, length=30)
	private String nombreJuegos;
	
	@ManyToOne
	@JoinColumn(name="id_categoria", nullable = false)
    private Categoria categoria;
	
	//@ManyToOne
	//@JoinColumn(name="id_detalle_venta", nullable = false)
    //private DetalleVenta detalleventa;
	@Positive(message="El precio debe ser mayor a cero")
	@Digits(integer = 4, fraction = 2,message="El precio debe tener dos decimales. Ejemplo: 1400.90")
	private float Precio;
	
	@PositiveOrZero(message="El stock debe ser un valor existente")
	private int Stock;
	
	public int getIdJuegos() {
		return idJuegos;
	}

	public void setIdJuegos(int idJuegos) {
		this.idJuegos = idJuegos;
	}

	public String getNombreJuegos() {
		return nombreJuegos;
	}

	public void setNombreJuegos(String nombreJuegos) {
		this.nombreJuegos = nombreJuegos;
	}

	public Categoria getCategoria() {
		return categoria;
	}
	
	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public float getPrecio() {
		return Precio;
	}

	public void setPrecio(float precio) {
		Precio = precio;
	}

	public int getStock() {
		return Stock;
	}

	public void setStock(int stock) {
		Stock = stock;
	}
	
	//public DetalleVenta GetDetalleVenta() {
		//return detalleventa;
	//}
	
	//public void SetDetalleVenta(DetalleVenta detalleventa) {
		//this.detalleventa = detalleventa;
	//}
}
