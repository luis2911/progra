package pe.edu.upc.spring.service;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.spring.model.Juegos;

public interface IJuegosService {
	public boolean insertar(Juegos juegos);
	public List<Juegos> listar();
	public void eliminar(int idJuegos);
	public boolean update (Juegos juegos);
	List<Juegos> buscarNombreJuegos(String nameJuegos);
	public Optional<Juegos> listarId(int idJuegos);
}
