package pe.edu.upc.spring.serviceimpl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.upc.spring.model.DetalleVenta;
import pe.edu.upc.spring.model.Juegos;
import pe.edu.upc.spring.repository.IDetalleVentaRepository;
import pe.edu.upc.spring.service.IDetalleVentaService;
import pe.edu.upc.spring.service.IJuegosService;

@Service
public class DetalleVentaServiceImpl implements IDetalleVentaService {

	@Autowired
	private IDetalleVentaRepository dD;

	@Autowired
	private IJuegosService juegoService;

	@Override
	@Transactional(rollbackFor = Exception.class)
	public boolean insertar(DetalleVenta detalleventa) throws Exception {

		Juegos juego = juegoService.listarId(detalleventa.getJuegos().getIdJuegos()).get();
		
		int stock = juego.getStock() - detalleventa.getCantidad();
		
		if(stock < 0) {
			throw new Exception("No hay stock del producto");
		}
		
		juego.setStock(stock);
		juegoService.update(juego);

		detalleventa.setPrecioUnitario(juego.getPrecio());
		
		DetalleVenta objDetalle = dD.save(detalleventa);

		if (objDetalle == null)
			return false;
		else
			return true;
	}

	@Override
	public List<DetalleVenta> listar() {
		return dD.findAll()
				.stream()
				.map(x-> {
					x.setPrecioTotal(x.getPrecioUnitario() * x.getCantidad());
					return x;
				}).collect(Collectors.toList());						
	}

	@Override
	public void eliminar(int idDetalleVenta) {
		dD.deleteById(idDetalleVenta);
	}

	@Override
	public boolean update(DetalleVenta detalleventa) {
		boolean flag = false;
		try {
			dD.save(detalleventa);
			flag = true;
		} catch (Exception ex) {
			System.out.println("Ocurrio un error");
		}
		return flag;
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<DetalleVenta> listarId(int idDetalleVenta) {
		return dD.findById(idDetalleVenta);
	}

	@Override
	public List<DetalleVenta> buscarIdDetalle(int idDetalleVenta) {
		return dD.buscarIdDetalle(idDetalleVenta);
	}

	@Override
	public List<DetalleVenta> buscarporIdVenta(int idVenta) {
		return dD.findByVentaId(idVenta);
	}

}
