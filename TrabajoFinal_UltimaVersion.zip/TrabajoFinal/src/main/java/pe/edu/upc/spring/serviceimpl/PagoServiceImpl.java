package pe.edu.upc.spring.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.upc.spring.model.Articulo;
import pe.edu.upc.spring.model.Pago;
import pe.edu.upc.spring.model.Venta;
import pe.edu.upc.spring.repository.IPagoRepository;
import pe.edu.upc.spring.service.IArticuloService;
import pe.edu.upc.spring.service.IPagoService;
import pe.edu.upc.spring.service.IVentaService;

@Service
public class PagoServiceImpl implements IPagoService {

	@Autowired
	private IPagoRepository pD;

	@Autowired
	private IVentaService ventaService;
	
	

	@Autowired
	private IArticuloService articuloService;

	@Override
	@Transactional(rollbackFor=Exception.class)
	public Integer insertar(Pago pago) throws Exception {
		int rpta = 1;
		//Juegos juego = juegosService.listarId(pago.getJuegos().getIdJuegos()).get();
		Articulo articulo = articuloService.listarId(pago.getArticulos().getIdArticulo()).get();		
		Venta venta = ventaService.listarId(pago.getVenta().getId()).get();
		
		Float precioTotal = (float) (venta.getMonto() - articulo.getPrecioArticulo());
		
		if (precioTotal <= 0) {
			throw new Exception("El precio tiene que ser mayor a cero : " +  precioTotal);
		}
		pago.setPreciototal(precioTotal);
		
		pD.save(pago);
		
		/*
		if (rpta == 1) {
			Pago obj = new Pago();
			if (0 <= juego.getStock() - pago.getCantidad()) {
				pD.save(pago);

				Optional<Pago> lista = pD.findById(pago.getIdPago());
				
				if(!lista.isPresent())
					throw new Exception("hubo un error");
					
					
				obj = lista.get();

				juego.setStock(juego.getStock() - obj.getCantidad());

				Float preciototal = (obj.getCantidad() * juego.getPrecio()) - articulo.getPrecioArticulo();

				if (preciototal <= 0) {
					throw new Exception("El precio tiene que ser mayor a cero :" + obj.getCantidad() + "x"
							+ juego.getPrecio() + "-" + articulo.getPrecioArticulo() + "=" + preciototal);
				}

				obj.setPreciototal(preciototal);

			} else {
				rpta = 0;
			}
		}*/
		return rpta;
	}

	@Override
	public List<Pago> listar() {
		return pD.findAll();
	}

	@Override
	public void eliminar(int idPago) {
		pD.deleteById(idPago);
	}

	public List<Pago> buscarIdPago(String TitularTarjeta) {
		return pD.buscarIdPago(TitularTarjeta);
	}

	@Override
	public boolean update(Pago pago) {
		boolean flag = false;
		try {
			pD.save(pago);
			flag = true;
		} catch (Exception ex) {
			System.out.println("Ocurrio un error");
		}
		return flag;
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<Pago> listarId(int idPago) {
		return pD.findById(idPago);
	}

}