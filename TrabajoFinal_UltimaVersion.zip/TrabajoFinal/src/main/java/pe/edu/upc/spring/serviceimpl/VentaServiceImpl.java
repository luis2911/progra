package pe.edu.upc.spring.serviceimpl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.upc.spring.model.Venta;
import pe.edu.upc.spring.repository.IVentaRepository;
import pe.edu.upc.spring.service.IDetalleVentaService;
import pe.edu.upc.spring.service.IVentaService;

@Service
public class VentaServiceImpl implements IVentaService {

	@Autowired
	private IVentaRepository vD;

	@Autowired
	private IDetalleVentaService detalleVentaService;

	@Override
	@Transactional
	public boolean insertar(Venta venta) {
		Venta objVenta = vD.save(venta);
		if (objVenta == null)
			return false;
		else
			return true;
	}

	@Override
	public List<Venta> listar() {
		return vD.findAll().stream().map(venta -> {

			Double totalVenta = detalleVentaService.buscarporIdVenta(venta.getId()).stream().map(detalle -> {
				return (double) (detalle.getCantidad() * detalle.getPrecioUnitario());
			}).collect(Collectors.toList()).stream().mapToDouble(f -> f.doubleValue()).sum();

			venta.setMonto(totalVenta);

			return venta;
		}).collect(Collectors.toList());
	}

	@Override
	public void eliminar(int idVenta) {
		vD.deleteById(idVenta);
	}

	public List<Venta> buscarId(int idVenta) {
		return vD.buscarId(idVenta);
	}

	@Override
	public List<Venta> buscarUser(String username) {
		return vD.buscarUser(username);
	}

	@Override
	public boolean update(Venta venta) {
		boolean flag = false;
		try {
			vD.save(venta);
			flag = true;
		} catch (Exception ex) {
			System.out.println("Ocurrio un error");
		}
		return flag;
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<Venta> listarId(int idVenta) {
		Optional<Venta> venta = vD.findById(idVenta);

		if(venta.isPresent()) {
			Double totalVenta = detalleVentaService.buscarporIdVenta(venta.get().getId()).stream().map(detalle -> {
				return (double) (detalle.getCantidad() * detalle.getPrecioUnitario());
			}).collect(Collectors.toList()).stream().mapToDouble(f -> f.doubleValue()).sum();
			
			venta.get().setMonto(totalVenta);
		}
		
		
		return venta;
	}

}
